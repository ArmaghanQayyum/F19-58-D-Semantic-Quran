<?php
$rule="hamzat_wasl";
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://localhost:8081/search",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>"\n{\"query\": \"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> SELECT * where {?s ?p ?o {SELECT ?s where {?s rdfs:label '$rule'}}}\"}",
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
?>

<?php
//Decode JSON
	$json_data = json_decode($response,true);
	
	$temp = $json_data['results']['bindings'];
	?>
<table style="width:100%">
	<style>
		table, th, td {
		border: 1px solid black;
	}
	</style>
	<tr>
		<th>Subject</th>
		<th>Predicate</th>
		<th>Object</th>
	</tr>
	<?php for ($x = 0; $x <= count($temp); $x++) { ?>
		<tr>
		<td><a><?php print_r($temp[$x]['s']['value']); ?></a></td>
		<td><?php print_r($temp[$x]['p']['value']); ?></td>
		<td><?php print_r($temp[$x]['o']['value']); ?></td>
		</tr>
		
	<?php } ?>
	
</table>
	//print_r($temp[0]);
    <script src="js/extention/choices.js"></script>
    <script>
      const choices = new Choices('[data-trigger]',
      {
        searchEnabled: false,
        itemSelectText: '',
      });

    </script>
  </body>
</html>

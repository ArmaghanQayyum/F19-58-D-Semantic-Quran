package pk.rdf.quranserver.pojo;

import javax.validation.constraints.NotBlank;

/**
 * Search request
 * 
 */
public class SearchRequest {

	/**
	 * SPARQL query
	 */
	@NotBlank
	private String query;

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

}

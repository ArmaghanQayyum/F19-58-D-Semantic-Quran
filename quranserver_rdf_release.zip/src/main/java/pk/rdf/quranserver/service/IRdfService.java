package pk.rdf.quranserver.service;

import pk.rdf.quranserver.pojo.SearchRequest;

/**
 * RDF service interface
 *
 */
public interface IRdfService {

	/**
	 * Search
	 * 
	 * @param request
	 *            search request
	 * @return triples in JSON format
	 */
	String search(SearchRequest request);

}

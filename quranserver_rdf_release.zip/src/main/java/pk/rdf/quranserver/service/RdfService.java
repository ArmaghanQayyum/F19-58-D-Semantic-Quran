package pk.rdf.quranserver.service;

import org.apache.jena.query.Dataset;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.ReadWrite;
import org.apache.jena.sparql.resultset.ResultsFormat;
import org.apache.jena.tdb.TDBFactory;
import org.springframework.stereotype.Service;

import pk.rdf.quranserver.pojo.SearchRequest;
import pk.rdf.quranserver.util.SipamQueryExecUtils;

/**
 * RDF service
 *
 */
@Service
public class RdfService implements IRdfService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see pk.rdf.quranserver.service.IRdfService#search(pk.rdf.quranserver.pojo.
	 * SearchRequest)
	 */
	@Override
	public String search(SearchRequest request) {
		// open dataset
		Dataset dataset = TDBFactory.createDataset("data");

		// start READ transaction
		dataset.begin(ReadWrite.READ);
		try {
			// create query
			Query q = QueryFactory.create(request.getQuery());
			// create query execution
			QueryExecution qexec = QueryExecutionFactory.create(q, dataset);
			// execute query execution
			return SipamQueryExecUtils.executeQuery(q, qexec, ResultsFormat.FMT_RS_JSON);
		} finally {
			dataset.end();
		}
	}

}

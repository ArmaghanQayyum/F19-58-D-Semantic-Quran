package pk.rdf.quranserver.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.jena.query.ARQ;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryException;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.riot.Lang;
import org.apache.jena.riot.resultset.rw.ResultsWriter;
import org.apache.jena.sparql.ARQConstants;
import org.apache.jena.sparql.core.Prologue;
import org.apache.jena.sparql.resultset.ResultsFormat;
import org.apache.jena.sparql.util.Context;

/**
 * Some utilities for query processing
 *
 */
public class SipamQueryExecUtils {

	/**
	 * Execute query
	 * 
	 * @param prologue
	 *            prolofue
	 * @param queryExecution
	 *            query execution
	 * @param outputFormat
	 *            output format
	 * @return result in selected output format
	 */
	public static String executeQuery(Prologue prologue, QueryExecution queryExecution, ResultsFormat outputFormat) {
		Query query = queryExecution.getQuery();
		if (query.isSelectType())
			return doSelectQuery(prologue, queryExecution, outputFormat);
		else
			throw new QueryException("Unrecognized query form");
	}

	/**
	 * Output result set
	 * 
	 * @param results
	 *            result set
	 * @param prologue
	 *            prologue
	 * @param outputFormat
	 *            output format
	 * @return result in selected output format
	 */
	private static String outputResultSet(ResultSet results, Prologue prologue, ResultsFormat outputFormat) {
		if (outputFormat.equals(ResultsFormat.FMT_UNKNOWN))
			outputFormat = ResultsFormat.FMT_TEXT;
		Lang lang = ResultsFormat.convert(outputFormat);
		if (lang != null) {
			Context context = ARQ.getContext().copy();
			context.set(ARQConstants.symPrologue, prologue);
			try (ByteArrayOutputStream stream = new ByteArrayOutputStream()) {
				ResultsWriter.create().context(context).lang(lang).build().write(stream, results);
				return streamToString(stream);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		try (ByteArrayOutputStream stream = new ByteArrayOutputStream()) {
			boolean done = ResultsFormat.oldWrite(stream, outputFormat, prologue, results);
			if (!done) {
				System.err.println("Unknown format request: " + outputFormat);
				return null;
			}
			return streamToString(stream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Stream to string
	 * 
	 * @param stream
	 *            stream
	 * @return string
	 */
	private static String streamToString(ByteArrayOutputStream stream) {
		try {
			return new String(stream.toByteArray(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Do select query
	 * 
	 * @param prologue
	 *            prologue
	 * @param qe
	 *            query execution
	 * @param outputFormat
	 *            output format
	 * @return result in output format
	 */
	private static String doSelectQuery(Prologue prologue, QueryExecution qe, ResultsFormat outputFormat) {
		if (prologue == null)
			prologue = qe.getQuery().getPrologue();
		if (outputFormat == null || outputFormat == ResultsFormat.FMT_UNKNOWN)
			outputFormat = ResultsFormat.FMT_TEXT;
		ResultSet results = qe.execSelect();
		return outputResultSet(results, prologue, outputFormat);
	}
}

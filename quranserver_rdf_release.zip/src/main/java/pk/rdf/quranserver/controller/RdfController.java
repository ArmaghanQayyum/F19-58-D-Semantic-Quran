package pk.rdf.quranserver.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pk.rdf.quranserver.pojo.SearchRequest;
import pk.rdf.quranserver.service.IRdfService;

/**
 * REST controller
 *
 */
@RestController
@RequestMapping
public class RdfController {

	/**
	 * RDF service
	 */
	@Autowired
	private IRdfService rdfService;

	/**
	 * Test endpoint
	 * 
	 * @return class name
	 */
	@GetMapping("/test")
	public String test() {
		return RdfController.class.getName();
	}

	/**
	 * Search endpoint
	 * 
	 * @param searchRequest
	 *            search request
	 * @return triples in JSON format
	 */
	@CrossOrigin
	@PostMapping("/search")
	public ResponseEntity<String> search(@Valid @RequestBody SearchRequest searchRequest) {
		return ResponseEntity.ok(rdfService.search(searchRequest));
	}

	/**
	 * Download endpoint
	 * 
	 * @return RDF file
	 */
	@CrossOrigin
	@GetMapping("/download")
	public ResponseEntity<Resource> download() {
		return ResponseEntity.ok().header("Content-Disposition", "attachment; filename*=UTF-8''quran.rdf;")
				.contentType(MediaType.parseMediaType("application/octet-stream"))
				.body(new FileSystemResource("quran.rdf"));

	}

}

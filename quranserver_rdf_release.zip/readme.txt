1. Run server from folder release/, just execute start script
2. Open in browser http://localhost:8081/test to make sure that server is running
3. Make POST request to http://localhost:8081/search with next headers and data:
	Headers:
		Content-Type: application/json
	Data:
		{"query": "YOUR SPARQL QUERY"}
4. Open in browser http://localhost:8081/download to download RDF file